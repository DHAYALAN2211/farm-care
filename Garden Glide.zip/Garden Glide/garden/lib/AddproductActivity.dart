import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class AddProductScreen extends StatefulWidget {
  @override
  _AddProductScreenState createState() => _AddProductScreenState();
}

class _AddProductScreenState extends State<AddProductScreen> {
  File? _image;

  Future<void> _selectImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xfff5ffec),
      appBar: AppBar(
        title: Text('Add Product'),
        backgroundColor: Colors.green,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Top Navigation Buttons
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    width: 200,
                    height: 65,
                    child: Image.asset('assets/ggtit.png'),
                  ),
                  IconButton(
                    icon: Icon(Icons.person),
                    onPressed: () {
                      Navigator.pushNamed(context, '/login');
                    },
                  ),
                ],
              ),

              SizedBox(height: 20),

              // Product Title
              Text(
                'Product title',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),

              SizedBox(height: 10),

              // Active Toggle (Check/Cross Icons)
              Row(
                children: [
                  Icon(Icons.check, color: Colors.green),
                  SizedBox(width: 10),
                  Text(
                    'Active',
                    style: TextStyle(fontSize: 20, color: Colors.grey[700]),
                  ),
                  Spacer(),
                  Icon(Icons.close, color: Colors.red),
                ],
              ),

              SizedBox(height: 20),

              // Add Image Section
              Center(
                child: GestureDetector(
                  onTap: _selectImage,
                  child: _image != null
                      ? Image.file(_image!, width: 120, height: 90)
                      : Image.asset('assets/addimage.png', width: 120, height: 90),
                ),
              ),

              SizedBox(height: 20),

              // Add Description
              Row(
                children: [
                  Icon(Icons.add),
                  SizedBox(width: 10),
                  Text(
                    'Add description',
                    style: TextStyle(fontSize: 19, color: Colors.grey),
                  ),
                ],
              ),

              SizedBox(height: 20),

              // Inventory Section
              Text(
                'Inventory',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Available', style: TextStyle(fontSize: 20)),
                  Text('--     0     +', style: TextStyle(fontSize: 20)),
                ],
              ),

              SizedBox(height: 20),

              // Shipping Section
              Row(
                children: [
                  Icon(Icons.local_shipping),
                  SizedBox(width: 10),
                  Text(
                    'Shipping',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ],
              ),

              SizedBox(height: 20),

              // Bottom Navigation Bar
              BottomNavigationBar(
                items: [
                  BottomNavigationBarItem(
                    icon: Icon(Icons.home),
                    label: 'Home',
                  ),
                  BottomNavigationBarItem(
                    icon: Icon(Icons.camera),
                    label: 'Camera',
                  ),
                  BottomNavigationBarItem(
                    icon: Icon(Icons.shopping_cart),
                    label: 'Cart',
                  ),
                  BottomNavigationBarItem(
                    icon: Icon(Icons.settings),
                    label: 'Settings',
                  ),
                ],
                onTap: (index) {
                  switch (index) {
                    case 0:
                      Navigator.pushNamed(context, '/home');
                      break;
                    case 1:
                      Navigator.pushNamed(context, '/scan');
                      break;
                    case 2:
                      Navigator.pushNamed(context, '/marketplace');
                      break;
                    case 3:
                      Navigator.pushNamed(context, '/settings');
                      break;
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}