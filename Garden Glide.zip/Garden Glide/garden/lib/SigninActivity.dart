import 'package:flutter/material.dart';

void main() {
  runApp(SigninScreen());
}

class SigninScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: SigninPage(),
    );
  }
}

class SigninPage extends StatefulWidget {
  @override
  _SigninPageState createState() => _SigninPageState();
}

class _SigninPageState extends State<SigninPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5FFEC),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(height: 30),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  icon: Image.asset('assets/arrow.png'),
                  iconSize: 30,
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => HomePage()),
                    );
                  },
                ),
                Image.asset(
                  'assets/ggtit.png',
                  width: 198,
                  height: 65,
                ),
                SizedBox(width: 50), // For balance, similar to the Android design
              ],
            ),
            SizedBox(height: 90),
            Text(
              'Sign Up',
              style: TextStyle(
                fontFamily: 'Alata',
                fontSize: 30,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            SizedBox(height: 50),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Create Account',
                    style: TextStyle(
                      fontFamily: 'Alata',
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF121712),
                    ),
                  ),
                  SizedBox(height: 40),
                  CustomInputField(
                    hintText: 'Username',
                  ),
                  SizedBox(height: 15),
                  CustomInputField(
                    hintText: 'Name',
                  ),
                  SizedBox(height: 15),
                  CustomInputField(
                    hintText: 'Password',
                    obscureText: true,
                  ),
                  SizedBox(height: 15),
                  CustomInputField(
                    hintText: 'Confirm Password',
                    obscureText: true,
                  ),
                  SizedBox(height: 30),
                  CustomButton(
                    buttonText: 'Sign Up',
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => HomePage()),
                      );
                    },
                  ),
                  SizedBox(height: 15),
                  CustomButton(
                    buttonText: 'Log In',
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => LoginPage()),
                      );
                    },
                  ),
                  SizedBox(height: 10),
                  Center(
                    child: Text(
                      'Terms and Privacy Policy',
                      style: TextStyle(
                        fontFamily: 'Alata',
                        color: Color(0xFF638763),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CustomInputField extends StatelessWidget {
  final String hintText;
  final bool obscureText;

  CustomInputField({required this.hintText, this.obscureText = false});

  @override
  Widget build(BuildContext context) {
    return TextField(
      obscureText: obscureText,
      decoration: InputDecoration(
        hintText: hintText,
        filled: true,
        fillColor: Color(0xFFDCF3D5),
        contentPadding: EdgeInsets.symmetric(vertical: 15, horizontal: 15),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide.none,
        ),
      ),
      style: TextStyle(
        fontFamily: 'Alata',
        color: Color(0xFF3D3D3D),
      ),
    );
  }
}

class CustomButton extends StatelessWidget {
  final String buttonText;
  final VoidCallback onPressed;

  CustomButton({required this.buttonText, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          padding: EdgeInsets.symmetric(vertical: 12),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
        child: Text(
          buttonText,
          style: TextStyle(
            fontFamily: 'Alata',
            color: Colors.black,
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text('Home Page'),
      ),
    );
  }
}

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text('Login Page'),
      ),
    );
  }
}
