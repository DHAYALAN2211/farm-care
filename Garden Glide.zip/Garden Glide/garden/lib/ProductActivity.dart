import 'package:flutter/material.dart';

class ProductActivity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5FFEC),
      body: Stack(
        children: [
          // Background Image
          Positioned(
            left: 60,
            bottom: 390,
            child: GestureDetector(
              onTap: () {
                // Navigate to AddproductActivity
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AddProductActivity()),
                );
              },
              child: Container(
                width: 284,
                height: 39,
                color: Colors.black, // Placeholder for the image
                // child: Image.asset('assets/images/background.png'), // Uncomment and replace with your actual image
              ),
            ),
          ),
          // Product Image
          Positioned(
            top: 170,
            left: 107,
            child: Image.asset(
              'assets/images/product.png', // Replace with your actual image path
              width: 200,
              height: 200,
            ),
          ),
          // Welcome Text
          Positioned(
            top: 500,
            left: 55,
            child: Text(
              "To start selling on Garden Glide, migrate your\nproducts or source new ones.",
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.black,
                fontSize: 13,
              ),
            ),
          ),
          // Add Your Products Text
          Positioned(
            top: 472,
            left: 145,
            child: Text(
              "Add your products",
              style: TextStyle(
                color: Color(0xFFD3D3D3),
                fontSize: 14,
              ),
            ),
          ),
          // First Up Text
          Positioned(
            top: 380,
            left: 80,
            child: Text(
              "First up: add your products",
              style: TextStyle(
                color: Color(0xFF5A5A5A),
                fontSize: 20,
                fontFamily: 'Alata',
              ),
            ),
          ),
          // User Icon
          Positioned(
            top: 25,
            right: 30,
            child: GestureDetector(
              onTap: () {
                // Navigate to LoginActivity
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => LoginActivity()),
                );
              },
              child: Image.asset(
                'assets/images/user.png', // Replace with your actual image path
                width: 70,
                height: 40,
              ),
            ),
          ),
          // Header Image
          Positioned(
            top: 22,
            left: 20,
            child: Image.asset(
              'assets/images/ggtit.png', // Replace with your actual image path
              width: 198,
              height: 65,
            ),
          ),
          // Navigation Bar
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              height: 58,
              color: Color(0xFFD8FDC1).withOpacity(0.5),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  GestureDetector(
                    onTap: () {
                      // Navigate to HomeActivity
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => HomeActivity()),
                      );
                    },
                    child: Image.asset(
                      'assets/images/home.png', // Replace with your actual image path
                      width: 50,
                      height: 52,
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      // Navigate to MarketplaceActivity
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => MarketplaceActivity()),
                      );
                    },
                    child: Image.asset(
                      'assets/images/market.png', // Replace with your actual image path
                      width: 44,
                      height: 40,
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      // Navigate to AddproductActivity
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => AddProductActivity()),
                      );
                    },
                    child: Image.asset(
                      'assets/images/tag.png', // Replace with your actual image path
                      width: 40,
                      height: 40,
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      // Navigate to SettingActivity
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => SettingActivity()),
                      );
                    },
                    child: Image.asset(
                      'assets/images/dot.png', // Replace with your actual image path
                      width: 55,
                      height: 55,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// Placeholder for the other activities
class AddProductActivity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(body: Center(child: Text('Add Product Activity')));
  }
}

class HomeActivity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(body: Center(child: Text('Home Activity')));
  }
}

class MarketplaceActivity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(body: Center(child: Text('Marketplace Activity')));
  }
}

class SettingActivity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(body: Center(child: Text('Setting Activity')));
  }
}

class LoginActivity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(body: Center(child: Text('Login Activity')));
  }
}

void main() {
  runApp(MaterialApp(
    home: ProductActivity(),
  ));
}
