import 'package:flutter/material.dart';

class AutoPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          width: double.infinity,
          height: double.infinity,
          color: Color(0xFFF5FFEC), // Background color
          child: SingleChildScrollView(
            child: Column(
              children: [
                // Top Section
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Image.asset(
                        'assets/ggtit.png', // Replace with your asset path
                        width: 198,
                        height: 65,
                        fit: BoxFit.cover,
                      ),
                      Image.asset(
                        'assets/user.png', // Replace with your asset path
                        width: 70,
                        height: 40,
                      ),
                    ],
                  ),
                ),
                
                // Time, Date, TopA, and Tick Section
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Image.asset(
                      'assets/time.png', // Replace with your asset path
                      width: 50,
                      height: 50,
                    ),
                    Image.asset(
                      'assets/date.png', // Replace with your asset path
                      width: 50,
                      height: 50,
                    ),
                    Image.asset(
                      'assets/topa.png', // Replace with your asset path
                      width: 50,
                      height: 50,
                    ),
                    Image.asset(
                      'assets/tick.png', // Replace with your asset path
                      width: 50,
                      height: 40,
                    ),
                  ],
                ),
                
                // "Turn Off" Button
                Padding(
                  padding: const EdgeInsets.only(top: 80),
                  child: ElevatedButton(
                    onPressed: () {
                      // Add your button logic here
                    },
                    style: ElevatedButton.styleFrom(
                      minimumSize: Size(360, 48),
                    ),
                    child: Text(
                      'Turn Off',
                      style: TextStyle(
                        fontSize: 18,
                        color: Colors.black,
                      ),
                    ),
                  ),
                ),
                
                // Watering History Section
                Padding(
                  padding: const EdgeInsets.only(top: 300, left: 25),
                  child: Text(
                    'Watering History', // Replace with your string resource
                    style: TextStyle(
                      fontFamily: 'Alata',
                      fontSize: 22,
                    ),
                  ),
                ),
                
                // Last Watered and Current Level Section
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Last Watered',
                            style: TextStyle(
                              color: Color(0xFF404340),
                              fontSize: 16,
                            ),
                          ),
                          Text(
                            'few minutes ago',
                            style: TextStyle(
                              color: Color(0xFF8FA491),
                              fontSize: 12,
                            ),
                          ),
                          Text(
                            'Next Watering',
                            style: TextStyle(
                              color: Color(0xFF434643),
                              fontSize: 15,
                            ),
                          ),
                          Text(
                            'In 2 days',
                            style: TextStyle(
                              color: Color(0xFF95AA96),
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Water Tank Level',
                            style: TextStyle(
                              color: Color(0xFF2C302C),
                              fontSize: 20,
                            ),
                          ),
                          Text(
                            '80%',
                            style: TextStyle(
                              color: Color(0xFF469200),
                              fontSize: 15,
                            ),
                          ),
                          SizedBox(height: 20),
                          Text(
                            'System Status',
                            style: TextStyle(
                              color: Color(0xFF313431),
                              fontSize: 20,
                            ),
                          ),
                          Text(
                            'Active',
                            style: TextStyle(
                              color: Color(0xFF494B48),
                              fontSize: 16,
                            ),
                          ),
                          Text(
                            'Yes',
                            style: TextStyle(
                              color: Color(0xFF44A029),
                              fontSize: 15,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                
                // Bottom Section Navigation Bar
                Container(
                  margin: EdgeInsets.only(top: 30),
                  color: Color(0xFFD8FDC1).withOpacity(0.5),
                  height: 58,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      IconButton(
                        icon: Image.asset('assets/home.png'), // Replace with your asset path
                        onPressed: () {},
                      ),
                      IconButton(
                        icon: Image.asset('assets/camera.png'), // Replace with your asset path
                        onPressed: () {},
                      ),
                      IconButton(
                        icon: Image.asset('assets/cart.png'), // Replace with your asset path
                        onPressed: () {},
                      ),
                      IconButton(
                        icon: Image.asset('assets/dot.png'), // Replace with your asset path
                        onPressed: () {},
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
