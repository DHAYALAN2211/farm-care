import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Garden Glide',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: MainActivity(),
    );
  }
}

class MainActivity extends StatefulWidget {
  @override
  _MainActivityState createState() => _MainActivityState();
}

class _MainActivityState extends State<MainActivity> {
  static const String thingspeakUrl =
      "https://api.thingspeak.com/channels/2559752/feeds.json?api_key=DIGU3A9AT7IW7Q4S&results=1";
  
  String _displayText = "Fetching data...";
  
  @override
  void initState() {
    super.initState();
    generateAndDisplayValue();
    fetchDataFromThingSpeak();
  }

  void generateAndDisplayValue() {
    final random = Random();
    double randomValue = 75 + random.nextDouble() * 20;
    setState(() {
      _displayText = "${randomValue.toStringAsFixed(2)}%"; // Display random value
    });
  }

  Future<void> fetchDataFromThingSpeak() async {
    if (await isNetworkAvailable()) {
      try {
        final response = await http.get(Uri.parse(thingspeakUrl));
        
        if (response.statusCode == 200) {
          parseAndDisplayData(response.body);
        } else {
          setState(() {
            _displayText = "Error fetching data: ${response.statusCode}";
          });
        }
      } catch (e) {
        setState(() {
          _displayText = "Error fetching data: ${e.toString()}";
        });
      }
    } else {
      setState(() {
        _displayText = "No internet connection available";
      });
    }
  }

  Future<bool> isNetworkAvailable() async {
    // Since Flutter doesn't have a direct way to check network connectivity,
    // we'll assume we have internet if we can make a request.
    try {
      final result = await InternetAddress.lookup('example.com');
      return result.isNotEmpty && result[0].rawAddress.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  void parseAndDisplayData(String response) {
    try {
      final json = jsonDecode(response);
      final feeds = json['feeds'];

      if (feeds.isNotEmpty) {
        final latestEntry = feeds[0];
        String soilMoisture = latestEntry['field1'] ?? 'none';
        String entryTime = latestEntry['created_at'] ?? 'none';
        
        setState(() {
          _displayText = "Soil Moisture Level: $soilMoisture\nTime of Entry: $entryTime";
        });
      } else {
        setState(() {
          _displayText = "No data found";
        });
      }
    } catch (e) {
      setState(() {
        _displayText = "Error parsing data: ${e.toString()}";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text(
          _displayText,
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}
