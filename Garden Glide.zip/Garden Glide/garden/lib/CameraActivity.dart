import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:tflite_flutter/tflite_flutter.dart';
import 'package:tflite_flutter_helper/tflite_flutter_helper.dart';

void main() => runApp(GardenGlideApp());

class GardenGlideApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        primaryColor: Colors.green,
      ),
      home: CameraScreen(),
    );
  }
}

class CameraScreen extends StatefulWidget {
  @override
  _CameraScreenState createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  File? _image;
  String _prediction = 'Prediction will be displayed here';
  late Interpreter _interpreter;

  @override
  void initState() {
    super.initState();
    _loadModel();
  }

  Future<void> _loadModel() async {
    try {
      _interpreter = await Interpreter.fromAsset('version_3.tflite');
      print('Model loaded successfully');
    } catch (e) {
      print('Failed to load model: $e');
    }
  }

  Future<void> _selectImage() async {
    final pickedFile =
        await ImagePicker().getImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
      _runInference(_image!);
    }
  }

  void _runInference(File imageFile) async {
    final imageBytes = await imageFile.readAsBytes();
    final bitmap = await decodeImageFromList(imageBytes);

    final inputSize = 224;
    final resizedImage = _resizeImage(bitmap, inputSize, inputSize);
    final input = _convertBitmapToByteBuffer(resizedImage, inputSize);

    final output = List.filled(1 * 1, 0.0).reshape([1, 1]);

    try {
      _interpreter.run(input, output);
      final prediction = output[0][0] as double;
      setState(() {
        _prediction = _interpretPrediction(prediction);
      });
    } catch (e) {
      print('Error running inference: $e');
    }
  }

  String _interpretPrediction(double prediction) {
    if (prediction.isNaN) return "Unable to detect";

    if (prediction > 0.5) {
      return "Class A";
    } else {
      return "Class B";
    }
  }

  ByteBuffer _convertBitmapToByteBuffer(
      Image bitmap, int inputWidth, int inputHeight) {
    final buffer = ByteData(inputWidth * inputHeight * 3).buffer;
    final pixels = List<int>.filled(inputWidth * inputHeight, 0);
    bitmap.toByteData().then((data) {
      for (int i = 0; i < pixels.length; i++) {
        final pixel = pixels[i];
        buffer.asFloat32List()[i * 3] = (pixel >> 16 & 0xFF) / 255.0;
        buffer.asFloat32List()[i * 3 + 1] = (pixel >> 8 & 0xFF) / 255.0;
        buffer.asFloat32List()[i * 3 + 2] = (pixel & 0xFF) / 255.0;
      }
    });
    return buffer;
  }

  Image _resizeImage(Image bitmap, int width, int height) {
    // Replace with proper image resize logic
    return bitmap;
  }

  Widget _buildPredictionText() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Text(
        _prediction,
        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Garden Glide'),
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(16),
          child: Column(
            children: [
              if (_image != null)
                Image.file(
                  _image!,
                  width: 300,
                  height: 300,
                  fit: BoxFit.cover,
                ),
              _buildPredictionText(),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _selectImage,
                child: Text('Select Image'),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => HomeScreen()),
          );
        },
        child: Icon(Icons.arrow_back),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
      ),
      body: Center(
        child: Text('Welcome to Garden Glide'),
      ),
    );
  }
}
