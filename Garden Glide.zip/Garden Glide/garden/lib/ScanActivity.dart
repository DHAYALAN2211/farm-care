import 'package:flutter/material.dart';

void main() {
  runApp(GardenGlideApp());
}

class GardenGlideApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Garden Glide',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: ScanPage(),
    );
  }
}

class ScanPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5FFEC),
      appBar: AppBar(
        title: Text('Recent Scans', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: Colors.black),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 16.0, horizontal: 20.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Image.asset('assets/images/ggtit.png', width: 198, height: 65),
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                        context, MaterialPageRoute(builder: (context) => LoginPage()));
                  },
                  child: Image.asset('assets/images/user.png', width: 70, height: 40),
                ),
              ],
            ),
          ),
          SizedBox(height: 16),
          Container(
            width: 337,
            height: 132,
            color: Color(0xFFD8FDC1),
            child: Center(
              child: Text(
                'Point the camera at your plant to get a diagnosis',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: 'Alata',
                  fontSize: 14.5,
                  color: Color(0xFF424242),
                ),
              ),
            ),
          ),
          SizedBox(height: 20),
          Text(
            'Image Prediction',
            style: TextStyle(
              fontFamily: 'Alata',
              fontSize: 20.5,
              color: Color(0xFF292929),
            ),
          ),
          SizedBox(height: 30),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Image.asset('assets/images/spid.png', width: 200, height: 200),
              Image.asset('assets/images/plant.png', width: 200, height: 200),
            ],
          ),
          SizedBox(height: 40),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              GestureDetector(
                onTap: () {
                  Navigator.push(
                      context, MaterialPageRoute(builder: (context) => CameraPage()));
                },
                child: Image.asset('assets/images/cam.png', width: 60, height: 60),
              ),
              GestureDetector(
                onTap: () {
                  // Add reload functionality here if needed
                },
                child: Image.asset('assets/images/reload.png', width: 40, height: 40),
              ),
            ],
          ),
        ],
      ),
      bottomNavigationBar: BottomAppBar(
        color: Color(0xFFD8FDC1),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 4.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              IconButton(
                icon: Image.asset('assets/images/home.png', width: 50, height: 50),
                onPressed: () {
                  Navigator.push(
                      context, MaterialPageRoute(builder: (context) => HomePage()));
                },
              ),
              IconButton(
                icon: Image.asset('assets/images/camera.png', width: 54, height: 50),
                onPressed: () {
                  Navigator.push(
                      context, MaterialPageRoute(builder: (context) => ScanPage()));
                },
              ),
              IconButton(
                icon: Image.asset('assets/images/cart.png', width: 50, height: 50),
                onPressed: () {
                  Navigator.push(
                      context, MaterialPageRoute(builder: (context) => MarketplacePage()));
                },
              ),
              IconButton(
                icon: Image.asset('assets/images/dot.png', width: 55, height: 55),
                onPressed: () {
                  Navigator.push(
                      context, MaterialPageRoute(builder: (context) => SettingsPage()));
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Login')),
      body: Center(child: Text('Login Page')),
    );
  }
}

class CameraPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Camera')),
      body: Center(child: Text('Camera Page')),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Home')),
      body: Center(child: Text('Home Page')),
    );
  }
}

class MarketplacePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Marketplace')),
      body: Center(child: Text('Marketplace Page')),
    );
  }
}

class SettingsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Settings')),
      body: Center(child: Text('Settings Page')),
    );
  }
}
