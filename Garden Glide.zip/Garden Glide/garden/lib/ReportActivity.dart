import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Garden Glide',
      home: ReportActivity(),
    );
  }
}

class ReportActivity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5FFEC),
      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildHeader(context),
            _buildPlantStatus(),
            _buildHumiditySection(),
            _buildTemperatureSection(),
            _buildAdviceSection(),
            _buildNavigationBar(context),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Row(
        children: [
          Expanded(
            child: Image.asset('assets/ggtit.png', height: 65), // Replace with your asset path
          ),
          IconButton(
            icon: Image.asset('assets/user.png', height: 40), // Replace with your asset path
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => LoginActivity()),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildPlantStatus() {
    return Column(
      children: [
        SizedBox(height: 160),
        Text("Monstera", style: TextStyle(color: Color(0xFF91A092), fontSize: 16)),
        Text("Your plant is looking good", style: TextStyle(color: Color(0xFF727471), fontSize: 20)),
        Image.asset('assets/tick.png', height: 50), // Replace with your asset path
      ],
    );
  }

  Widget _buildHumiditySection() {
    return Column(
      children: [
        SizedBox(height: 20),
        Image.asset('assets/ghumidity.png', height: 284), // Replace with your asset path
        Text("Last 30 Days", style: TextStyle(color: Color(0xFF788B78), fontSize: 20)),
        Text("60%", style: TextStyle(color: Colors.black, fontSize: 31, fontWeight: FontWeight.bold)),
        Text("Humidity", style: TextStyle(color: Color(0xFF6F726F), fontSize: 31)),
      ],
    );
  }

  Widget _buildTemperatureSection() {
    return Column(
      children: [
        SizedBox(height: 50),
        Image.asset('assets/glight.png', height: 284), // Replace with your asset path
        Text("Last 30 Days", style: TextStyle(color: Color(0xFF788B78), fontSize: 20)),
        Text("Fertility", style: TextStyle(color: Color(0xFF6F726F), fontSize: 31)),
        Image.asset('assets/gtemperature.png', height: 284), // Replace with your asset path
        Text("Last 30 Days", style: TextStyle(color: Color(0xFF788B78), fontSize: 20)),
        Text("68F", style: TextStyle(color: Colors.black, fontSize: 31, fontWeight: FontWeight.bold)),
        Text("Temperature", style: TextStyle(color: Color(0xFF6F726F), fontSize: 31)),
      ],
    );
  }

  Widget _buildAdviceSection() {
    return Column(
      children: [
        SizedBox(height: 20),
        Text("What to Know", style: TextStyle(color: Color(0xFF6F726F), fontSize: 24, fontWeight: FontWeight.bold)),
        Text("Keep soil damp, but not too wet", style: TextStyle(color: Color(0xFF788B78), fontSize: 18)),
        Text("Fertilize once a month in spring and summer", style: TextStyle(color: Color(0xFF788B78), fontSize: 18)),
      ],
    );
  }

  Widget _buildNavigationBar(BuildContext context) {
    return BottomNavigationBar(
      items: [
        BottomNavigationBarItem(
          icon: Image.asset('assets/home.png', height: 50), // Replace with your asset path
          label: '',
        ),
        BottomNavigationBarItem(
          icon: Image.asset('assets/camera.png', height: 50), // Replace with your asset path
          label: '',
        ),
        BottomNavigationBarItem(
          icon: Image.asset('assets/cart.png', height: 50), // Replace with your asset path
          label: '',
        ),
        BottomNavigationBarItem(
          icon: Image.asset('assets/dot.png', height: 50), // Replace with your asset path
          label: '',
        ),
      ],
      currentIndex: 0,
      onTap: (index) {
        switch (index) {
          case 0:
            Navigator.push(context, MaterialPageRoute(builder: (context) => HomeActivity()));
            break;
          case 1:
            Navigator.push(context, MaterialPageRoute(builder: (context) => ScanActivity()));
            break;
          case 2:
            Navigator.push(context, MaterialPageRoute(builder: (context) => MarketplaceActivity()));
            break;
          case 3:
            Navigator.push(context, MaterialPageRoute(builder: (context) => SettingActivity()));
            break;
        }
      },
    );
  }
}

// Placeholder for other activities
class LoginActivity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(body: Center(child: Text("Login Activity")));
  }
}

class HomeActivity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(body: Center(child: Text("Home Activity")));
  }
}

class ScanActivity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(body: Center(child: Text("Scan Activity")));
  }
}

class MarketplaceActivity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(body: Center(child: Text("Marketplace Activity")));
  }
}

class SettingActivity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(body: Center(child: Text("Settings Activity")));
  }
}