import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Garden Glide Marketplace',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: MarketplaceActivity(),
    );
  }
}

class MarketplaceActivity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            color: Color(0xFFF5FFEC),
            padding: EdgeInsets.all(16.0),
            child: Column(
              children: [
                // Top Box
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Image.asset(
                      'assets/ggtit.png', // Make sure to have this image in your assets
                      width: 198,
                      height: 65,
                    ),
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => HomeActivity()),
                        );
                      },
                      child: Image.asset(
                        'assets/user.png', // Make sure to have this image in your assets
                        width: 70,
                        height: 40,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 120),
                Text(
                  "My Store",
                  style: TextStyle(
                    fontFamily: 'Alata',
                    fontSize: 29,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF616161),
                  ),
                ),
                SizedBox(height: 80),
                Text(
                  "Welcome to your Marketplace, User",
                  style: TextStyle(
                    fontFamily: 'Alata',
                    fontSize: 19,
                    color: Color(0xFF8B8B8B),
                  ),
                ),
              ],
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              width: double.infinity,
              padding: EdgeInsets.symmetric(vertical: 20),
              color: Color(0xFFD8FDC1).withOpacity(0.5),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    "0 of 4 tasks complete",
                    style: TextStyle(
                      fontFamily: 'Alata',
                      fontSize: 14,
                      color: Color(0xFF929292),
                    ),
                  ),
                  Text(
                    "Your trial just started",
                    style: TextStyle(
                      fontFamily: 'Alata',
                      fontSize: 16,
                      color: Color(0xFF8B8B8B),
                    ),
                  ),
                  Text(
                    "Setup guide",
                    style: TextStyle(
                      fontFamily: 'Alata',
                      fontSize: 23,
                      color: Color(0xFF5D5D5D),
                    ),
                  ),
                  SizedBox(height: 5),
                  Image.asset(
                    'assets/flag.png', // Make sure to have this image in your assets
                    width: 62,
                    height: 61,
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              height: 58,
              color: Colors.transparent,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => HomeActivity()),
                      );
                    },
                    child: Image.asset(
                      'assets/home.png', // Make sure to have this image in your assets
                      width: 50,
                      height: 52,
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => MarketplaceActivity()),
                      );
                    },
                    child: Image.asset(
                      'assets/market.png', // Make sure to have this image in your assets
                      width: 44,
                      height: 40,
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => AddProductActivity()),
                      );
                    },
                    child: Image.asset(
                      'assets/tag.png', // Make sure to have this image in your assets
                      width: 40,
                      height: 40,
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => SettingActivity()),
                      );
                    },
                    child: Image.asset(
                      'assets/dot.png', // Make sure to have this image in your assets
                      width: 55,
                      height: 55,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// Dummy Activity Classes for Navigation
class HomeActivity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Home')),
      body: Center(child: Text('Home Screen')),
    );
  }
}

class AddProductActivity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Add Product')),
      body: Center(child: Text('Add Product Screen')),
    );
  }
}

class SettingActivity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Settings')),
      body: Center(child: Text('Settings Screen')),
    );
  }
}
