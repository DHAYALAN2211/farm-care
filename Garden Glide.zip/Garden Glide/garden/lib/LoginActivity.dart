import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Garden Glide',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: LoginActivity(),
    );
  }
}

class LoginActivity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5FFEC),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Image at the top
            Container(
              alignment: Alignment.topRight,
              margin: EdgeInsets.only(top: -10, right: 90),
              child: Image.asset(
                'assets/ggtit.png',
                width: 198,
                height: 65,
                fit: BoxFit.contain,
              ),
            ),
            SizedBox(height: 8),
            // Arrow icon
            GestureDetector(
              onTap: () {
                // Navigate to HomeActivity
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => HomeActivity()),
                );
              },
              child: Image.asset(
                'assets/arrow.png',
                width: 30,
                height: 28,
                fit: BoxFit.contain,
              ),
            ),
            // Welcome Text
            SizedBox(height: 60),
            Text(
              'Welcome Back!',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: 'Alata',
                fontSize: 30,
                fontWeight: FontWeight.bold,
                color: Color(0xFF121712),
              ),
            ),
            // Username Container
            Container(
              width: 360,
              height: 56,
              decoration: BoxDecoration(
                color: Colors.green[100], // Replace with your midG color
                borderRadius: BorderRadius.circular(8),
              ),
              padding: EdgeInsets.all(16),
              margin: EdgeInsets.only(top: 20),
              child: Text(
                'Username',
                style: TextStyle(
                  fontFamily: 'Alata',
                  fontSize: 16,
                  color: Color(0xFF3D3D3D),
                ),
              ),
            ),
            SizedBox(height: 10),
            // Password Container
            Container(
              width: 360,
              height: 56,
              decoration: BoxDecoration(
                color: Colors.green[100], // Replace with your midG color
                borderRadius: BorderRadius.circular(8),
              ),
              padding: EdgeInsets.all(16),
              child: Text(
                'Password',
                style: TextStyle(
                  fontFamily: 'Alata',
                  fontSize: 16,
                  color: Color(0xFF3D3D3D),
                ),
              ),
            ),
            SizedBox(height: 20),
            // Login Button
            ElevatedButton(
              onPressed: () {
                // Handle login logic here
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => HomeActivity()),
                );
              },
              style: ElevatedButton.styleFrom(
                textStyle: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              child: Container(
                width: 360,
                height: 48,
                alignment: Alignment.center,
                child: Text('Login'),
              ),
            ),
            SizedBox(height: 20),
            // Signup Text
            GestureDetector(
              onTap: () {
                // Navigate to SigninActivity
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SigninActivity()),
                );
              },
              child: Text(
                'Sign Up',
                style: TextStyle(
                  fontFamily: 'Alata',
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF121712),
                ),
                textAlign: TextAlign.center,
              ),
            ),
            SizedBox(height: 10),
            // Forgot Password Text
            Text(
              'Forgot Password?',
              style: TextStyle(
                fontSize: 14,
                color: Color(0xFF638763),
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

// Dummy classes for HomeActivity and SigninActivity
class HomeActivity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Home Activity')),
      body: Center(child: Text('Welcome to Home Activity!')),
    );
  }
}

class SigninActivity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Sign In Activity')),
      body: Center(child: Text('Welcome to Sign In Activity!')),
    );
  }
}
