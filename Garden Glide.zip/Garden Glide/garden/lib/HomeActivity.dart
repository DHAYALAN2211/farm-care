import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:math';

void main() {
  runApp(GardenGlideApp());
}

class GardenGlideApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Garden Glide',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  static const int minValue = 65;
  static const int maxValue = 95;
  int currentValue = 0;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    updateRandomValue();
    timer = Timer.periodic(Duration(seconds: 5), (timer) {
      updateRandomValue();
    });
  }

  void updateRandomValue() {
    setState(() {
      currentValue = Random().nextInt(maxValue - minValue + 1) + minValue;
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Color(0xFFF5FFEC),
        child: Stack(
          children: [
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: Container(
                height: 255,
                color: Color(0xFF1B571E),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 71, left: 20),
              child: Text(
                'Hello\n   Username!',
                style: TextStyle(
                  fontFamily: 'Alata',
                  color: Color(0xFFD8FDC1),
                  fontSize: 34,
                ),
              ),
            ),
            Positioned(
              top: 142,
              right: 20,
              child: IconButton(
                icon: Image.asset('assets/user2.png'),
                iconSize: 51,
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ReportActivity()),
                  );
                },
              ),
            ),
            Positioned(
              top: 220,
              left: 62,
              child: Container(
                width: 275,
                height: 45,
                color: Color(0xFFD9D9D9),
              ),
            ),
            Positioned(
              top: 222,
              left: 57,
              child: Text(
                'Your plant is looking good\n',
                style: TextStyle(
                  fontFamily: 'Alata',
                  color: Colors.black,
                  fontSize: 18,
                ),
              ),
            ),
            Positioned(
              top: 219,
              right: 20,
              child: Image.asset('assets/plantg.png', width: 32, height: 31),
            ),
            Positioned(
              top: 334,
              left: 40,
              child: Container(
                width: 315,
                height: 92,
                color: Color(0xFFD8FDC1),
              ),
            ),
            Positioned(
              top: 480,
              left: 37,
              child: Container(
                width: 315,
                height: 92,
                color: Color(0xFFD8FDC1),
              ),
            ),
            Positioned(
              top: 342,
              left: 25,
              child: Text(
                'Moisture level',
                style: TextStyle(
                  fontFamily: 'Alata',
                  color: Color(0xFF3E2900),
                  fontSize: 22,
                ),
              ),
            ),
            Positioned(
              top: 490,
              left: 10,
              child: Text(
                'Fertilizer level',
                style: TextStyle(
                  fontFamily: 'Alata',
                  color: Color(0xFF3E2900),
                  fontSize: 22,
                ),
              ),
            ),
            Positioned(
              top: 353,
              right: 20,
              child: Image.asset('assets/droplet.png', width: 40, height: 40),
            ),
            Positioned(
              top: 355,
              right: 25,
              child: Text(
                '$currentValue%',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
            ),
            Positioned(
              top: 497,
              right: 20,
              child: Text(
                '- -%',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF3E2900),
                ),
              ),
            ),
            Positioned(
              top: 494,
              right: 20,
              child: Image.asset('assets/fert.png', width: 50, height: 50),
            ),
            Positioned(
              bottom: 70,
              left: 20,
              child: Text(
                'Last Watered:\n ',
                style: TextStyle(
                  fontFamily: 'Alata',
                  color: Color(0xFF1B571E),
                  fontSize: 20,
                ),
              ),
            ),
            Positioned(
              bottom: 0,
              left: 57,
              child: Text(
                'Plants were watered 9 hours ago\n',
                style: TextStyle(
                  fontFamily: 'Alata',
                  color: Colors.black,
                  fontSize: 18,
                ),
              ),
            ),
            Positioned(
              top: 379,
              left: 56,
              child: Text(
                'Optimal soil moisture ensures healthy crop growth!',
                style: TextStyle(
                  fontFamily: 'Alata',
                  color: Color(0xFF3E2900),
                  fontSize: 14,
                ),
              ),
            ),
            Positioned(
              top: 528,
              left: 56,
              child: Text(
                'Perfect fertilizer levels promote maximum yield!',
                style: TextStyle(
                  fontFamily: 'Alata',
                  color: Color(0xFF3E2900),
                  fontSize: 14,
                ),
              ),
            ),
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Container(
                height: 58,
                color: Color(0x80FFD8FDC1),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    IconButton(
                      icon: Image.asset('assets/crop.png'),
                      iconSize: 50,
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => CroprecommendActivity()),
                        );
                      },
                    ),
                    IconButton(
                      icon: Image.asset('assets/cam.png'),
                      iconSize: 50,
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => ScanActivity()),
                        );
                      },
                    ),
                    IconButton(
                      icon: Image.asset('assets/analysis.png'),
                      iconSize: 50,
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => ReportActivity()),
                        );
                      },
                    ),
                    IconButton(
                      icon: Image.asset('assets/cart.png'),
                      iconSize: 50,
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => MarketplaceActivity()),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Dummy classes for navigation (you need to implement these)
class ReportActivity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text('Report')), body: Center(child: Text('Report Activity')));
  }
}

class CroprecommendActivity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text('Crop Recommendation')), body: Center(child: Text('Crop Recommendation Activity')));
  }
}

class ScanActivity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text('Scan')), body: Center(child: Text('Scan Activity')));
  }
}

class MarketplaceActivity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text('Marketplace')), body: Center(child: Text('Marketplace Activity')));
  }
}