import 'package:flutter/material.dart';

class SettingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xfff5ffec),
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Image.asset(
              'assets/ggtit.png',
              width: 198,
              height: 65,
            ),
            IconButton(
              icon: Image.asset('assets/user.png'),
              iconSize: 40,
              onPressed: () {
                Navigator.pushNamed(context, '/login');
              },
            ),
          ],
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 20),
            Text(
              'Settings',
              style: TextStyle(
                fontSize: 26,
                fontFamily: 'Alata',
                color: Color(0xff616161),
              ),
            ),
            SizedBox(height: 20),
            settingItem('Your Profile'),
            settingItem('Languages'),
            settingItem('Markets'),
            settingItem('Domains'),
            settingItem('Brand'),
            settingItem('Notification'),
            settingItem('Customer data'),
            settingItem('Customer privacy'),
            settingItem('Policies'),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Color(0xFFD8FDC1).withOpacity(0.5),
        items: [
          BottomNavigationBarItem(
            icon: IconButton(
              icon: Image.asset('assets/home.png'),
              onPressed: () {
                Navigator.pushNamed(context, '/home');
              },
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: IconButton(
              icon: Image.asset('assets/market.png'),
              onPressed: () {
                Navigator.pushNamed(context, '/product');
              },
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: IconButton(
              icon: Image.asset('assets/tag.png'),
              onPressed: () {
                Navigator.pushNamed(context, '/addproduct');
              },
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: IconButton(
              icon: Image.asset('assets/dot.png'),
              onPressed: () {
                Navigator.pushNamed(context, '/settings');
              },
            ),
            label: '',
          ),
        ],
      ),
    );
  }

  Widget settingItem(String title) {
    return Padding(
      padding: const EdgeInsets.only(top: 20.0),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 20,
          fontFamily: 'Alata',
          color: Color(0xff616161),
        ),
      ),
    );
  }
}
import 'package:flutter/material.dart';

class SettingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xfff5ffec),
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Image.asset(
              'assets/ggtit.png',
              width: 198,
              height: 65,
            ),
            IconButton(
              icon: Image.asset('assets/user.png'),
              iconSize: 40,
              onPressed: () {
                Navigator.pushNamed(context, '/login');
              },
            ),
          ],
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),D
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 20),
            Text(
              'Settings',
              style: TextStyle(
                fontSize: 26,
                fontFamily: 'Alata',
                color: Color(0xff616161),
              ),
            ),
            SizedBox(height: 20),
            settingItem('Your Profile'),
            settingItem('Languages'),
            settingItem('Markets'),
            settingItem('Domains'),
            settingItem('Brand'),
            settingItem('Notification'),
            settingItem('Customer data'),
            settingItem('Customer privacy'),
            settingItem('Policies'),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Color(0xFFD8FDC1).withOpacity(0.5),
        items: [
          BottomNavigationBarItem(
            icon: IconButton(
              icon: Image.asset('assets/home.png'),
              onPressed: () {
                Navigator.pushNamed(context, '/home');
              },
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: IconButton(
              icon: Image.asset('assets/market.png'),
              onPressed: () {
                Navigator.pushNamed(context, '/product');
              },
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: IconButton(
              icon: Image.asset('assets/tag.png'),
              onPressed: () {
                Navigator.pushNamed(context, '/addproduct');
              },
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: IconButton(
              icon: Image.asset('assets/dot.png'),
              onPressed: () {
                Navigator.pushNamed(context, '/settings');
              },
            ),
            label: '',
          ),
        ],
      ),
    );
  }

  Widget settingItem(String title) {
    return Padding(
      padding: const EdgeInsets.only(top: 20.0),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 20,
          fontFamily: 'Alata',
          color: Color(0xff616161),
        ),
      ),
    );
  }
}
