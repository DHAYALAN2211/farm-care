import 'package:flutter/material.dart';
// Assume you have a CropClassifier class that is imported
// import 'crop_classifier.dart';

class CropRecommendScreen extends StatefulWidget {
  @override
  _CropRecommendScreenState createState() => _CropRecommendScreenState();
}

class _CropRecommendScreenState extends State<CropRecommendScreen> {
  // Assuming CropClassifier is properly defined
  // late CropClassifier cropClassifier;

  @override
  void initState() {
    super.initState();
    // Initialize the classifier here
    // try {
    //   cropClassifier = CropClassifier();
    // } catch (e) {
    //   print('Error initializing classifier: $e');
    // }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Crop Recommendation'),
        backgroundColor: Colors.green[300],
      ),
      body: Container(
        color: Color(0xfff5ffec),
        child: Column(
          children: [
            const SizedBox(height: 40),
            Text(
              'Crop Recommendation',
              style: TextStyle(
                fontSize: 30,
                color: Color(0xff626262),
                fontFamily: 'Alata',
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 60),
            _buildPredictionBox("Crop recommended", "Predicted Crop: Wheat"),
            const SizedBox(height: 50),
            _buildPredictionBox("Fertilizer required", "Predicted Crop: Urea"),
            Spacer(),
            _buildNavigationBar(context),
          ],
        ),
      ),
    );
  }

  Widget _buildPredictionBox(String title, String result) {
    return Column(
      children: [
        Text(
          title,
          style: TextStyle(
            fontSize: 25,
            fontFamily: 'Alata',
            color: Colors.black,
          ),
        ),
        const SizedBox(height: 10),
        Container(
          width: 317,
          height: 124,
          color: Color(0xffd9d9d9),
          child: Center(
            child: Text(
              result,
              style: TextStyle(
                fontSize: 20,
                fontFamily: 'Alata',
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildNavigationBar(BuildContext context) {
    return Container(
      height: 58,
      color: Color(0x80FFD8FDC1),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          IconButton(
            icon: Image.asset('assets/home.png'),
            onPressed: () {
              Navigator.pushNamed(context, '/home');
            },
          ),
          IconButton(
            icon: Image.asset('assets/market.png'),
            onPressed: () {
              Navigator.pushNamed(context, '/marketplace');
            },
          ),
          IconButton(
            icon: Image.asset('assets/tag.png'),
            onPressed: () {
              Navigator.pushNamed(context, '/addProduct');
            },
          ),
          IconButton(
            icon: Image.asset('assets/dot.png'),
            onPressed: () {
              Navigator.pushNamed(context, '/settings');
            },
          ),
        ],
      ),
    );
  }
}
